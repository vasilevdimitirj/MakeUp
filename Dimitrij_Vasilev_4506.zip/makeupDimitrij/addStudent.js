function addNewStudent() {
  if (window.XMLHttpRequest) {
    xmlhttp = new XMLHttpRequest();
  } else {
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  let newStudent;

  xmlhttp.onreadystatechange = function () {
    let firstName = document.querySelector("input[name='firstName']").value;
    let lastName = document.querySelector("input[name='lastName']").value;
    let studentId = document.querySelector("input[name='studentId']").value;
    let email = document.querySelector("input[name='email']").value;

    newStudent = {
      firstName,
      lastName,
      studentId,
      email,
    };

    console.log(JSON.stringify(newStudent));
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      window.open("table.html", "_self");
    }
  };

  xmlhttp.open("POST", "https://ip-uacs.herokuapp.com/api/student", true);
  xmlhttp.setRequestHeader("Content-Type", "application/json");
  xmlhttp.send(JSON.stringify(newStudent));
}

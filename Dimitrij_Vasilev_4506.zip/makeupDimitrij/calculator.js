function calculate() {
  let degrees = document.getElementById("degrees").value;
  let scale = document.getElementById("scale").value;

  if (window.XMLHttpRequest) {
    xmlhttp = new XMLHttpRequest();
  } else {
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange = function () {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      let result = xmlhttp.responseText;

      if (scale == "celsius") {
        result += "F";
      } else {
        result += "C";
      }

      document.getElementById("result").innerText = result;
    }
  };

  let url = "";

  if (scale == "celsius") {
    url = "https://ip-uacs.herokuapp.com/api/Convert/ToFahrenheit/" + degrees;
  } else {
    url = "https://ip-uacs.herokuapp.com/api/Convert/ToCelsius/" + degrees;
  }

  xmlhttp.open("POST", url, true);
  xmlhttp.send();
}

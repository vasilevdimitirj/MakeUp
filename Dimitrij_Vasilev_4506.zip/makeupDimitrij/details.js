let json;

function getStudent() {
  if (window.XMLHttpRequest) {
    xmlhttp = new XMLHttpRequest();
  } else {
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }

  xmlhttp.onreadystatechange = function () {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      json = JSON.parse(xmlhttp.responseText);

      let result = document.querySelector("input[name='studentIdInput']").value;

      for (const x in json) {
        let student = json[x];

        if (student.studentId && student.studentId == result) {
          let studentDetailsDiv = document.getElementById("student");

          let data =
            "<p>Student ID: " +
            student.studentId +
            "</p>" +
            "<p>First Name: " +
            student.firstName +
            "</p>" +
            "<p>Last Name: " +
            student.lastName +
            "</p>" +
            "<p>Email: " +
            student.email +
            "</p>";

          studentDetailsDiv.innerHTML = data;

          return;
        }
      }
      document.getElementById("student").innerHTML =
        "<b style='color:red;'>" + result + " is not a valid student ID.</b>";
    }
  };

  xmlhttp.open("GET", "https://ip-uacs.herokuapp.com/api/student", true);
  xmlhttp.send();
}
